package com.v2ray.ang.ui.main

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import com.v2ray.ang.R
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.extension.toTrafficString

private val IosCardShape = RoundedCornerShape(24.dp)
private val IosListShape = 16.dp
private val IosWarnYellow = Color(0xFFFFD60A)

// ---------------------------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------------------------

@Composable
internal fun IosHeader(palette: IosPalette, onMenuClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(palette.card)
                .clickable(role = Role.Button, onClick = onMenuClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_menu_24dp),
                contentDescription = stringResource(R.string.acc_open_menu),
                modifier = Modifier.size(20.dp),
                tint = palette.accent
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = stringResource(R.string.ios_owner_name),
            color = palette.textPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------------------------

@Composable
internal fun IosEmptyState(palette: IosPalette, onAdd: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(palette.heroBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_ios_link),
                contentDescription = null,
                modifier = Modifier.size(44.dp),
                tint = Color.White
            )
        }
        Spacer(Modifier.height(20.dp))
        Text(
            text = stringResource(R.string.ios_empty_title),
            color = palette.textPrimary,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.ios_empty_text),
            color = palette.textSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(22.dp))
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(palette.accentBrush)
                .clickable(role = Role.Button, onClick = onAdd)
                .padding(horizontal = 26.dp, vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stringResource(R.string.ios_add_subscription),
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Subscription card + configs
// ---------------------------------------------------------------------------------------------

@Composable
internal fun IosSubscriptionContent(
    group: GroupMapItem,
    mainViewModel: MainViewModel,
    selectedGuid: String?,
    entrancePhase: Int,
    palette: IosPalette,
    onAction: (MainAction) -> Unit,
    onEditName: () -> Unit,
    onOpenDetails: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val groupStateFlow = remember(group.id) { mainViewModel.serverGroupState(group.id) }
    val groupState by groupStateFlow.collectAsStateWithLifecycle()
    val rows = groupState.rows

    Column(modifier = modifier.fillMaxWidth()) {
        IosSubscriptionCard(
            group = group,
            palette = palette,
            onEditName = onEditName,
            onRefresh = { onAction(MainAction.UpdateGroupSubscription(group.id)) },
            modifier = Modifier.iosEntrance(entrancePhase, 120)
        )
        if (rows.isEmpty()) {
            Text(
                text = stringResource(R.string.ios_no_configs),
                color = palette.textSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp, vertical = 40.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(top = 12.dp, bottom = 150.dp)
            ) {
                itemsIndexed(items = rows, key = { _, row -> row.guid }) { index, row ->
                    IosConfigRow(
                        row = row,
                        index = index,
                        count = rows.size,
                        isSelected = row.guid == selectedGuid,
                        palette = palette,
                        onSelect = { onAction(MainAction.SelectServer(row.guid)) },
                        onOpenDetails = { onOpenDetails(row.guid) },
                        modifier = Modifier
                            .animateItem()
                            .iosEntrance(
                                // Only the first screenful flies in; rows scrolled to later show instantly.
                                phase = if (index < IOS_ENTRANCE_ROWS) entrancePhase else INTRO_DONE,
                                delayMs = 240 + index * 60
                            )
                    )
                }
            }
        }
    }
}

private const val IOS_ENTRANCE_ROWS = 9

@Composable
private fun IosSubscriptionCard(
    group: GroupMapItem,
    palette: IosPalette,
    onEditName: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val usageInfo = group.usageInfo
    val model = remember(usageInfo) {
        usageInfo?.let { buildSubscriptionInfoUiModel(it, System.currentTimeMillis()) }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(IosCardShape)
            .background(palette.heroBrush)
            .padding(horizontal = 16.dp, vertical = 11.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = group.remarks,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IosGlassButton(
                iconRes = R.drawable.ic_refresh_24dp,
                contentDescription = stringResource(R.string.title_sub_update),
                onClick = onRefresh
            )
            Spacer(Modifier.width(6.dp))
            IosGlassButton(
                iconRes = R.drawable.ic_edit_24dp,
                contentDescription = stringResource(R.string.ios_acc_edit_name),
                onClick = onEditName
            )
        }
        Spacer(Modifier.height(8.dp))
        if (model == null) {
            Text(
                text = stringResource(R.string.ios_no_usage_info),
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp
            )
        } else {
            val totalText = if (model.totalBytes > 0L) {
                model.totalBytes.toTrafficString()
            } else {
                stringResource(R.string.sub_info_unlimited)
            }
            val trafficValue = stringResource(
                R.string.sub_info_traffic,
                model.usedBytes.toTrafficString(),
                totalText
            )
            val expireMillis = model.expireMillis
            val daysLeft = if (expireMillis != null) {
                daysUntil(expireMillis, System.currentTimeMillis())
            } else {
                null
            }
            val daysValue = when {
                expireMillis == null -> "∞"
                model.expired -> stringResource(R.string.ios_expired)
                else -> daysLeft.toString()
            }

            Column(Modifier.semantics(mergeDescendants = true) {}) {
                IosStatRow(label = stringResource(R.string.ios_data), value = trafficValue)
                val trafficFraction = model.trafficFraction
                if (trafficFraction != null) {
                    Spacer(Modifier.height(4.dp))
                    IosBar(fraction = trafficFraction, highlight = model.trafficLow)
                }
                Spacer(Modifier.height(8.dp))
                IosStatRow(label = stringResource(R.string.ios_days_left), value = daysValue)
                if (daysLeft != null) {
                    Spacer(Modifier.height(4.dp))
                    IosBar(
                        fraction = daysLeftFraction(daysLeft),
                        highlight = daysLeft <= 3L
                    )
                }
            }
        }
    }
}

@Composable
private fun IosStatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = Color.White.copy(alpha = 0.82f),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            color = Color.White,
            style = TextStyle(textDirection = TextDirection.Ltr, fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun IosBar(fraction: Float, highlight: Boolean) {
    val animated by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), label = "iosBar")
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.28f))
    ) {
        Box(
            Modifier
                .fillMaxWidth(animated)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(if (highlight) IosWarnYellow else Color.White)
        )
    }
}

@Composable
private fun IosGlassButton(iconRes: Int, contentDescription: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.22f))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = contentDescription,
            modifier = Modifier.size(16.dp),
            tint = Color.White
        )
    }
}

@Composable
private fun IosConfigRow(
    row: ServerRowUiModel,
    index: Int,
    count: Int,
    isSelected: Boolean,
    palette: IosPalette,
    onSelect: () -> Unit,
    onOpenDetails: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape: Shape = when {
        count == 1 -> RoundedCornerShape(IosListShape)
        index == 0 -> RoundedCornerShape(topStart = IosListShape, topEnd = IosListShape)
        index == count - 1 -> RoundedCornerShape(bottomStart = IosListShape, bottomEnd = IosListShape)
        else -> RectangleShape
    }
    val selectedDescription = if (isSelected) stringResource(R.string.acc_selected_server) else null
    val delay = row.testDelayMillis
    val delayText = when {
        delay > 0L -> stringResource(R.string.server_test_delay_value, delay)
        delay < 0L -> stringResource(R.string.ios_delay_failed)
        else -> ""
    }
    val delayColor = when {
        delay < 0L -> palette.bad
        delay < 400L -> palette.good
        delay < 900L -> palette.warn
        else -> palette.bad
    }

    Column(
        modifier = modifier
            .padding(horizontal = 16.dp)
            .clip(shape)
            .background(if (isSelected) palette.card.tintedWith(palette.accentSoft) else palette.card)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .selectable(selected = isSelected, role = Role.RadioButton, onClick = onSelect)
                    .semantics(mergeDescendants = true) {
                        if (selectedDescription != null) stateDescription = selectedDescription
                    }
                    .padding(start = 14.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IosSelectionMark(isSelected = isSelected, palette = palette)
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = row.remarks,
                        color = palette.textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (row.typeDescription.isNotBlank()) {
                        Spacer(Modifier.height(1.dp))
                        Text(
                            text = row.typeDescription,
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (delayText.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = delayText,
                        color = delayColor,
                        style = TextStyle(textDirection = TextDirection.Ltr, fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                        maxLines = 1
                    )
                }
            }
            AnimatedVisibility(
                visible = isSelected,
                enter = fadeIn() + scaleIn(initialScale = 0.4f),
                exit = fadeOut() + scaleOut(targetScale = 0.4f)
            ) {
                Box(
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(palette.accentSoft)
                        .clickable(role = Role.Button, onClick = onOpenDetails),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_settings_24dp),
                        contentDescription = stringResource(R.string.ios_acc_config_details),
                        modifier = Modifier.size(18.dp),
                        tint = palette.accent
                    )
                }
            }
        }
        if (index < count - 1) {
            Box(
                Modifier
                    .padding(start = 49.dp)
                    .fillMaxWidth()
                    .height(0.5.dp)
                    .background(palette.separator)
            )
        }
    }
}

private fun Color.tintedWith(background: Color): Color {
    // Paints [background] (usually translucent) on top of this opaque color.
    val a = background.alpha
    return Color(
        red = background.red * a + red * (1f - a),
        green = background.green * a + green * (1f - a),
        blue = background.blue * a + blue * (1f - a),
        alpha = 1f
    )
}

@Composable
private fun IosSelectionMark(isSelected: Boolean, palette: IosPalette) {
    if (isSelected) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(palette.accentBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_ios_check),
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = Color.White
            )
        }
    } else {
        Box(
            Modifier
                .size(22.dp)
                .border(1.5.dp, palette.separator, CircleShape)
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Bottom bar: add button, delay test button and the connect button
// ---------------------------------------------------------------------------------------------

@Composable
internal fun IosBottomBar(
    palette: IosPalette,
    isRunning: Boolean,
    isTesting: Boolean,
    testProgress: String?,
    onAdd: () -> Unit,
    onTest: () -> Unit,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, palette.background.copy(alpha = 0.94f), palette.background)
                )
            )
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, top = 30.dp, bottom = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IosCircleButton(
                palette = palette,
                contentDescription = stringResource(R.string.acc_add_subscription),
                onClick = onAdd
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_add_24dp),
                    contentDescription = null,
                    modifier = Modifier.size(26.dp),
                    tint = palette.accent
                )
            }
            IosCircleButton(
                palette = palette,
                contentDescription = stringResource(R.string.ios_acc_delay_test),
                onClick = onTest
            ) {
                if (isTesting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(40.dp),
                        strokeWidth = 2.5.dp,
                        color = palette.accent
                    )
                    if (!testProgress.isNullOrBlank()) {
                        Text(
                            text = testProgress,
                            color = palette.accent,
                            style = TextStyle(textDirection = TextDirection.Ltr, fontSize = 9.sp, fontWeight = FontWeight.SemiBold),
                            maxLines = 1
                        )
                    }
                } else {
                    Icon(
                        painter = painterResource(R.drawable.ic_ios_bolt),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = palette.accent
                    )
                }
            }
            IosConnectButton(
                palette = palette,
                isRunning = isRunning,
                onClick = onToggle,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/** A 56dp round button with a soft shadow and a press-in feel. */
@Composable
private fun IosCircleButton(
    palette: IosPalette,
    contentDescription: String,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(targetValue = if (pressed) 0.9f else 1f, label = "circlePress")
    Box(
        modifier = Modifier
            .size(56.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(elevation = 6.dp, shape = CircleShape)
            .clip(CircleShape)
            .background(palette.card)
            .semantics { this.contentDescription = contentDescription }
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

private const val CONNECT_PENDING_TIMEOUT_MS = 7000L

@Composable
private fun IosConnectButton(
    palette: IosPalette,
    isRunning: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(targetValue = if (pressed) 0.97f else 1f, label = "connectPress")

    // A request is in flight from the tap until the service state flips (or a timeout passes).
    var pending by remember { mutableStateOf(false) }
    LaunchedEffect(isRunning) { pending = false }
    LaunchedEffect(pending) {
        if (pending) {
            delay(CONNECT_PENDING_TIMEOUT_MS)
            pending = false
        }
    }

    // 0 = disconnected look (gradient), 1 = connected look (outlined card).
    val connected by animateFloatAsState(
        targetValue = if (isRunning) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow),
        label = "connectLook"
    )

    // One-shot effects whenever the state flips (not on first composition).
    val pop = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    val firstRun = remember { booleanArrayOf(true) }
    LaunchedEffect(isRunning) {
        if (firstRun[0]) {
            firstRun[0] = false
        } else {
            pop.snapTo(0.92f)
            if (isRunning) {
                burst.snapTo(0f)
                burst.animateTo(1f, tween(900, easing = LinearEasing))
            }
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = Spring.StiffnessMedium))
        }
    }

    val shape = RoundedCornerShape(28.dp)
    val contentColor = lerp(Color.White, palette.accent, connected.coerceIn(0f, 1f))
    val ringColor = palette.good
    // 0 = connect, 1 = connecting, 2 = connected, 3 = disconnecting
    val look = when {
        pending && !isRunning -> 1
        pending && isRunning -> 3
        isRunning -> 2
        else -> 0
    }

    Box(
        modifier = modifier
            .height(56.dp)
            .graphicsLayer {
                val scale = pressScale * pop.value
                scaleX = scale
                scaleY = scale
            }
            .drawBehind {
                // Expanding ring that fades out once the connection is up.
                val b = burst.value
                if (b > 0f && b < 1f) {
                    val grow = 22.dp.toPx() * b
                    drawRoundRect(
                        color = ringColor.copy(alpha = 0.55f * (1f - b)),
                        topLeft = Offset(-grow, -grow),
                        size = Size(size.width + grow * 2, size.height + grow * 2),
                        cornerRadius = CornerRadius(28.dp.toPx() + grow),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
            .drawBehind {
                val radius = CornerRadius(28.dp.toPx())
                val f = connected.coerceIn(0f, 1f)
                drawRoundRect(color = palette.card, cornerRadius = radius)
                drawRoundRect(brush = palette.accentBrush, cornerRadius = radius, alpha = 1f - f)
                drawRoundRect(
                    color = palette.accent,
                    cornerRadius = radius,
                    alpha = f,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
            .clip(shape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = {
                    pending = true
                    onClick()
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        if (pending) {
            ConnectShimmer(color = if (isRunning) palette.accent else Color.White)
        }
        Row(
            modifier = Modifier.padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (look == 2) {
                PulseDot(color = palette.good)
                Spacer(Modifier.width(10.dp))
            }
            Crossfade(targetState = look, animationSpec = tween(250), label = "connectIcon") { state ->
                Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                    if (state == 1 || state == 3) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.5.dp,
                            color = contentColor
                        )
                    } else {
                        Icon(
                            painter = painterResource(
                                if (state == 2) R.drawable.ic_stop_24dp else R.drawable.ic_ios_power
                            ),
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = contentColor
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Crossfade(targetState = look, animationSpec = tween(250), label = "connectLabel") { state ->
                Text(
                    text = stringResource(
                        when (state) {
                            1 -> R.string.ios_connecting
                            2 -> R.string.ios_disconnect
                            3 -> R.string.ios_disconnecting
                            else -> R.string.ios_connect
                        }
                    ),
                    color = contentColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
    }
}

/** A highlight band that sweeps across the button while a request is in flight. */
@Composable
private fun BoxScope.ConnectShimmer(color: Color) {
    val transition = rememberInfiniteTransition(label = "connectShimmer")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    Box(
        Modifier
            .matchParentSize()
            .drawBehind {
                val band = size.width * 0.45f
                val x = -band + (size.width + band) * sweep
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, color.copy(alpha = 0.32f), Color.Transparent),
                        startX = x,
                        endX = x + band
                    )
                )
            }
    )
}

/** Small green dot that gently breathes while the VPN is connected. */
@Composable
private fun PulseDot(color: Color) {
    val transition = rememberInfiniteTransition(label = "pulseDot")
    val pulse by transition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier
            .size(9.dp)
            .graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            }
            .clip(CircleShape)
            .background(color)
    )
}
