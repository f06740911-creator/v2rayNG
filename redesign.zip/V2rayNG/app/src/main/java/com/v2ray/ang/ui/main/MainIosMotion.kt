package com.v2ray.ang.ui.main

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// Same curves as the web intro this is modelled on: a fast launch and a long, gentle settle.
private val ExpoOut = CubicBezierEasing(0.19f, 1f, 0.22f, 1f)
private val SoftOut = CubicBezierEasing(0.3f, 0.6f, 0.4f, 1f)

private const val SPLASH_LETTER_MS = 1700
private const val SPLASH_FIRST_LETTER_DELAY_MS = 450L
private const val SPLASH_LETTER_STEP_MS = 70L
private const val SPLASH_HOLD_MS = 1300L

/** Intro phases shared by the splash and the main screen: 0 = splash, 1 = main entering, 2 = done. */
internal const val INTRO_SPLASH = 0
internal const val INTRO_ENTERING = 1
internal const val INTRO_DONE = 2

/**
 * Full-screen intro: "Design and Development :" and then the name, letter by letter, each letter
 * flying in from depth (rotation + scale), un-blurring and fading in. Tap to skip.
 */
@Composable
internal fun IosSplash(
    dark: Boolean,
    phase: Int,
    onFadeStart: () -> Unit,
    onFinished: () -> Unit,
) {
    val name = "Hassan Zakizadeh"
    val background = if (dark) Color(0xFF1C1B1F) else Color.White
    val ink = if (dark) Color(0xFFF2EEFF) else Color(0xFF1C1E21)
    val lavender = if (dark) Color(0xFFB9A8F0) else Color(0xFF7F68CF)

    val alreadyIn = phase >= INTRO_ENTERING
    val label = remember { Animatable(if (alreadyIn) 1f else 0f) }
    val letters = remember { List(name.length) { Animatable(if (alreadyIn) 1f else 0f) } }
    val fade = remember { Animatable(1f) }
    val skip = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!alreadyIn) {
            val intro = launch {
                launch { label.animateTo(1f, tween(SPLASH_LETTER_MS, easing = LinearEasing)) }
                letters.forEachIndexed { index, letter ->
                    launch {
                        delay(SPLASH_FIRST_LETTER_DELAY_MS + index * SPLASH_LETTER_STEP_MS + (index * 37L) % 41L)
                        letter.animateTo(1f, tween(SPLASH_LETTER_MS, easing = LinearEasing))
                    }
                }
                delay(SPLASH_FIRST_LETTER_DELAY_MS + letters.size * SPLASH_LETTER_STEP_MS + SPLASH_HOLD_MS)
            }
            val watcher = launch {
                snapshotFlow { skip.value }.first { it }
                intro.cancel()
            }
            intro.join()
            watcher.cancel()
        }
        onFadeStart()
        fade.animateTo(0f, tween(600))
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(background)
            .pointerInput(Unit) { detectTapGestures { skip.value = true } },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            SplashPiece(
                text = stringResource(R.string.ios_splash_label),
                progress = label,
                color = lavender,
                fontSize = 14.sp,
                fontFamily = FontFamily.Default,
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.Center) {
                name.forEachIndexed { index, ch ->
                    SplashPiece(
                        text = if (ch == ' ') " " else ch.toString(),
                        progress = letters[index],
                        color = ink,
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Serif,
                    )
                }
            }
        }
    }
}

@Composable
private fun SplashPiece(
    text: String,
    progress: Animatable<Float, AnimationVector1D>,
    color: Color,
    fontSize: TextUnit,
    fontFamily: FontFamily,
) {
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    Text(
        text = text,
        color = color,
        fontSize = fontSize,
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.graphicsLayer {
            val t = progress.value
            val opacity = SoftOut.transform((t * 2f).coerceIn(0f, 1f))
            val unblur = ExpoOut.transform((t / 0.8f).coerceIn(0f, 1f))
            val settle = ExpoOut.transform(t)
            val inverse = 1f - settle
            alpha = opacity
            rotationX = 62f * inverse
            translationY = -44f * density * inverse
            val scale = 1f + 1.4f * inverse
            scaleX = scale
            scaleY = scale
            cameraDistance = 12f * density
            if (canBlur) {
                val radius = 22f * (1f - unblur)
                renderEffect = if (radius > 0.5f) BlurEffect(radius, radius, TileMode.Decal) else null
            }
        }
    )
}

/**
 * Lets a block of the main screen fly in (fade, a short drop from above, a slight tilt) once the
 * intro hands over. Only GPU layer properties are animated, so it stays cheap.
 *
 * [phase] is one of the INTRO_ constants; blocks created after the intro finished show instantly.
 */
@Composable
internal fun Modifier.iosEntrance(phase: Int, delayMs: Int): Modifier {
    val progress = remember { Animatable(if (phase >= INTRO_DONE) 1f else 0f) }
    val started = phase >= INTRO_ENTERING
    LaunchedEffect(started) {
        if (started && progress.value < 1f) {
            delay(delayMs.toLong())
            progress.animateTo(1f, tween(900, easing = LinearEasing))
        }
    }
    return this.graphicsLayer {
        val t = progress.value
        if (t < 1f) {
            alpha = SoftOut.transform((t * 1.8f).coerceIn(0f, 1f))
            val inverse = 1f - ExpoOut.transform(t)
            translationY = -26f * density * inverse
            rotationX = 30f * inverse
            val scale = 1f + 0.12f * inverse
            scaleX = scale
            scaleY = scale
            cameraDistance = 12f * density
        }
    }
}
