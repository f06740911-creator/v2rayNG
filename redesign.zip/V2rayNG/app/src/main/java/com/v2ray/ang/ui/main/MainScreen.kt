package com.v2ray.ang.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.ui.compose.LocalDarkTheme
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    mainViewModel: MainViewModel,
    onAction: (MainAction) -> Unit,
    onNavigate: (MainDestination) -> Unit,
    onSaveProfile: (String, ProfileItem) -> Unit,
) {
    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
    val isLoading by mainViewModel.isLoading.collectAsStateWithLifecycle()

    val palette = if (LocalDarkTheme.current) DarkIosPalette else LightIosPalette
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showAddSheet by rememberSaveable { mutableStateOf(false) }
    var showRenameSheet by rememberSaveable { mutableStateOf(false) }
    // Which of the INTRO_ phases the app is in: splash, main screen flying in, or settled.
    var introPhase by rememberSaveable { mutableStateOf(INTRO_SPLASH) }
    // Guid of the config whose detail page is open.
    var detailGuid by rememberSaveable { mutableStateOf<String?>(null) }

    // This app keeps a single subscription; the view model only ever exposes that one.
    val group = uiState.groups.firstOrNull()
    val testProgress = (uiState.status as? MainStatus.TestProgress)?.progress

    Box(Modifier.fillMaxSize()) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            MainDrawerContent(
                drawerState = drawerState,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    onNavigate(route)
                }
            )
        }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(palette.background)
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                IosHeader(
                    palette = palette,
                    onMenuClick = { scope.launch { drawerState.open() } },
                    modifier = Modifier.iosEntrance(introPhase, 0)
                )
                if (isLoading) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp),
                        color = palette.accent,
                        trackColor = Color.Transparent,
                    )
                } else {
                    // Keeps the layout from jumping while the loading bar comes and goes.
                    Box(Modifier.height(2.dp))
                }
                if (group == null) {
                    IosEmptyState(
                        palette = palette,
                        onAdd = { showAddSheet = true },
                        modifier = Modifier
                            .weight(1f)
                            .iosEntrance(introPhase, 120)
                    )
                } else {
                    IosSubscriptionContent(
                        group = group,
                        mainViewModel = mainViewModel,
                        selectedGuid = uiState.selectedGuid,
                        entrancePhase = introPhase,
                        palette = palette,
                        onAction = onAction,
                        onEditName = { showRenameSheet = true },
                        onOpenDetails = { guid -> detailGuid = guid },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            IosBottomBar(
                palette = palette,
                isRunning = uiState.isRunning,
                isTesting = uiState.isTesting,
                testProgress = testProgress,
                onAdd = { showAddSheet = true },
                onTest = {
                    if (uiState.isTesting) onAction(MainAction.CancelTesting)
                    else onAction(MainAction.TestRealAllServers)
                },
                onToggle = { onAction(MainAction.ToggleService) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .iosEntrance(introPhase, 420)
            )

            val openGuid = detailGuid
            if (openGuid != null && group != null) {
                IosConfigDetailHost(
                    groupId = group.id,
                    guid = openGuid,
                    mainViewModel = mainViewModel,
                    palette = palette,
                    onBack = { detailGuid = null },
                    onSave = onSaveProfile,
                    onAdvancedEdit = { guid, profile -> onAction(MainAction.EditServer(guid, profile)) },
                )
            }

            if (showAddSheet) {
                IosTextSheet(
                    palette = palette,
                    iconRes = R.drawable.ic_ios_link,
                    title = stringResource(
                        if (group == null) R.string.ios_add_subscription
                        else R.string.ios_replace_subscription
                    ),
                    hint = stringResource(R.string.ios_sub_hint),
                    placeholder = stringResource(R.string.ios_link_placeholder),
                    initialValue = "",
                    confirmLabel = stringResource(R.string.ios_add),
                    keyboardType = KeyboardType.Uri,
                    showPaste = true,
                    isValid = ::isSubscriptionLink,
                    onConfirm = { link -> onAction(MainAction.SetSubscription(link)) },
                    onDismiss = { showAddSheet = false },
                )
            }
            if (showRenameSheet && group != null) {
                IosTextSheet(
                    palette = palette,
                    iconRes = R.drawable.ic_edit_24dp,
                    title = stringResource(R.string.ios_rename_title),
                    hint = stringResource(R.string.ios_rename_hint),
                    placeholder = stringResource(R.string.ios_name_placeholder),
                    initialValue = group.remarks,
                    confirmLabel = stringResource(R.string.ios_save),
                    keyboardType = KeyboardType.Text,
                    showPaste = false,
                    isValid = { name -> name.isNotBlank() },
                    onConfirm = { name -> onAction(MainAction.RenameSubscription(group.id, name)) },
                    onDismiss = { showRenameSheet = false },
                )
            }
        }
    }
    if (introPhase < INTRO_DONE) {
        IosSplash(
            dark = LocalDarkTheme.current,
            phase = introPhase,
            onFadeStart = { introPhase = INTRO_ENTERING },
            onFinished = { introPhase = INTRO_DONE },
        )
    }
    }
}
