package com.v2ray.ang.ui.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.enums.EConfigType
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------------------------
// Field catalogue
// ---------------------------------------------------------------------------------------------

private const val SECTION_CONNECTION = 0
private const val SECTION_TRANSPORT = 1
private const val SECTION_SECURITY = 2
private const val SECTION_OTHER = 3

private val STREAM_TYPES = setOf(EConfigType.VMESS, EConfigType.VLESS, EConfigType.TROJAN)
private val ADDRESS_TYPES = setOf(
    EConfigType.VMESS, EConfigType.VLESS, EConfigType.SHADOWSOCKS, EConfigType.SOCKS,
    EConfigType.HTTP, EConfigType.TROJAN, EConfigType.WIREGUARD, EConfigType.HYSTERIA2
)
private val TLS_TYPES = STREAM_TYPES + EConfigType.HYSTERIA2
private val PASSWORD_TYPES = setOf(
    EConfigType.SHADOWSOCKS, EConfigType.TROJAN, EConfigType.HYSTERIA2, EConfigType.SOCKS, EConfigType.HTTP
)
private val USER_TYPES = setOf(EConfigType.SOCKS, EConfigType.HTTP)
private val ID_TYPES = setOf(EConfigType.VMESS, EConfigType.VLESS)
private val CIPHER_TYPES = setOf(EConfigType.VMESS, EConfigType.VLESS, EConfigType.SHADOWSOCKS)
private val WG_TYPES = setOf(EConfigType.WIREGUARD)
private val H2_TYPES = setOf(EConfigType.HYSTERIA2)
private val VLESS_ONLY = setOf(EConfigType.VLESS)

/**
 * One editable property of a profile. It is shown when its type applies and it has a value; in the
 * editor it is also shown empty when [editAlways] is set.
 */
private class DetailField(
    val label: String,
    val section: Int,
    val types: Set<EConfigType>,
    val read: (ProfileItem) -> String?,
    val write: (ProfileItem, String) -> Unit,
    val editAlways: Boolean = false,
    val secret: Boolean = false,
    val numeric: Boolean = false,
)

private fun text(
    label: String,
    section: Int,
    types: Set<EConfigType>,
    read: (ProfileItem) -> String?,
    write: (ProfileItem, String?) -> Unit,
    editAlways: Boolean = false,
    secret: Boolean = false,
    numeric: Boolean = false,
) = DetailField(
    label = label,
    section = section,
    types = types,
    read = read,
    write = { profile, value -> write(profile, value.trim().ifEmpty { null }) },
    editAlways = editAlways,
    secret = secret,
    numeric = numeric,
)

private val DETAIL_FIELDS: List<DetailField> = listOf(
    text("Server", SECTION_CONNECTION, ADDRESS_TYPES, { it.server }, { p, v -> p.server = v }, editAlways = true),
    text("Port", SECTION_CONNECTION, ADDRESS_TYPES, { it.serverPort }, { p, v -> p.serverPort = v }, editAlways = true, numeric = true),
    text("UUID", SECTION_CONNECTION, ID_TYPES, { it.password }, { p, v -> p.password = v }, editAlways = true),
    text("Password", SECTION_CONNECTION, PASSWORD_TYPES, { it.password }, { p, v -> p.password = v }, editAlways = true, secret = true),
    text("Username", SECTION_CONNECTION, USER_TYPES, { it.username }, { p, v -> p.username = v }, editAlways = true),
    text("Encryption", SECTION_CONNECTION, CIPHER_TYPES, { it.method }, { p, v -> p.method = v }, editAlways = true),
    text("Flow", SECTION_CONNECTION, VLESS_ONLY, { it.flow }, { p, v -> p.flow = v }, editAlways = true),
    text("Private key", SECTION_CONNECTION, WG_TYPES, { it.secretKey }, { p, v -> p.secretKey = v }, editAlways = true, secret = true),
    text("Peer public key", SECTION_CONNECTION, WG_TYPES, { it.publicKey }, { p, v -> p.publicKey = v }, editAlways = true),
    text("Pre-shared key", SECTION_CONNECTION, WG_TYPES, { it.preSharedKey }, { p, v -> p.preSharedKey = v }, secret = true),
    text("Address", SECTION_CONNECTION, WG_TYPES, { it.localAddress }, { p, v -> p.localAddress = v }, editAlways = true),
    text("MTU", SECTION_CONNECTION, WG_TYPES, { it.mtu?.toString() }, { p, v -> p.mtu = v?.toIntOrNull() }, numeric = true),
    text("Reserved", SECTION_CONNECTION, WG_TYPES, { it.reserved }, { p, v -> p.reserved = v }),
    text("DNS", SECTION_CONNECTION, WG_TYPES, { it.remoteDNS }, { p, v -> p.remoteDNS = v }),

    text("Network", SECTION_TRANSPORT, STREAM_TYPES, { it.network }, { p, v -> p.network = v }, editAlways = true),
    text("Header type", SECTION_TRANSPORT, STREAM_TYPES, { it.headerType }, { p, v -> p.headerType = v }),
    text("Host", SECTION_TRANSPORT, STREAM_TYPES, { it.host }, { p, v -> p.host = v }, editAlways = true),
    text("Path", SECTION_TRANSPORT, STREAM_TYPES, { it.path }, { p, v -> p.path = v }, editAlways = true),
    text("Service name", SECTION_TRANSPORT, STREAM_TYPES, { it.serviceName }, { p, v -> p.serviceName = v }),
    text("Authority", SECTION_TRANSPORT, STREAM_TYPES, { it.authority }, { p, v -> p.authority = v }),
    text("Mode", SECTION_TRANSPORT, STREAM_TYPES, { it.mode }, { p, v -> p.mode = v }),
    text("Seed", SECTION_TRANSPORT, STREAM_TYPES, { it.seed }, { p, v -> p.seed = v }),

    text("Security", SECTION_SECURITY, STREAM_TYPES, { it.security }, { p, v -> p.security = v }, editAlways = true),
    text("SNI", SECTION_SECURITY, TLS_TYPES, { it.sni }, { p, v -> p.sni = v }, editAlways = true),
    text("ALPN", SECTION_SECURITY, TLS_TYPES, { it.alpn }, { p, v -> p.alpn = v }),
    text("Fingerprint", SECTION_SECURITY, STREAM_TYPES, { it.fingerPrint }, { p, v -> p.fingerPrint = v }),
    text("Public key", SECTION_SECURITY, STREAM_TYPES, { it.publicKey }, { p, v -> p.publicKey = v }),
    text("Short ID", SECTION_SECURITY, STREAM_TYPES, { it.shortId }, { p, v -> p.shortId = v }),
    text("SpiderX", SECTION_SECURITY, STREAM_TYPES, { it.spiderX }, { p, v -> p.spiderX = v }),

    text("Obfs password", SECTION_OTHER, H2_TYPES, { it.obfsPassword }, { p, v -> p.obfsPassword = v }, secret = true),
    text("Port hopping", SECTION_OTHER, H2_TYPES, { it.portHopping }, { p, v -> p.portHopping = v }),
    text("Hop interval", SECTION_OTHER, H2_TYPES, { it.portHoppingInterval }, { p, v -> p.portHoppingInterval = v }),
    text("Upload", SECTION_OTHER, H2_TYPES, { it.bandwidthUp }, { p, v -> p.bandwidthUp = v }),
    text("Download", SECTION_OTHER, H2_TYPES, { it.bandwidthDown }, { p, v -> p.bandwidthDown = v }),
)

private const val EDIT_KEY_NAME = "\u0000name"

// ---------------------------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------------------------

/**
 * Full-screen, graphical view of the selected config. "Edit" turns the values into inputs for the
 * common fields; "Advanced editor" opens the regular editor for everything else.
 */
@Composable
internal fun IosConfigDetailHost(
    groupId: String,
    guid: String,
    mainViewModel: MainViewModel,
    palette: IosPalette,
    onBack: () -> Unit,
    onSave: (String, ProfileItem) -> Unit,
    onAdvancedEdit: (String, ProfileItem) -> Unit,
) {
    val groupFlow = remember(groupId) { mainViewModel.serverGroupState(groupId) }
    val groupState by groupFlow.collectAsStateWithLifecycle()
    val row = groupState.rows.firstOrNull { it.guid == guid }
    if (row == null) {
        // The config disappeared (for example after a subscription update).
        LaunchedEffect(Unit) { onBack() }
        return
    }
    IosConfigDetailPage(
        row = row,
        palette = palette,
        onBack = onBack,
        onSave = { updated -> onSave(guid, updated) },
        onAdvancedEdit = { onAdvancedEdit(guid, row.profile) },
    )
}

@Composable
private fun IosConfigDetailPage(
    row: ServerRowUiModel,
    palette: IosPalette,
    onBack: () -> Unit,
    onSave: (ProfileItem) -> Unit,
    onAdvancedEdit: () -> Unit,
) {
    val profile = row.profile
    var editing by remember { mutableStateOf(false) }
    var justSaved by remember { mutableStateOf(false) }
    val edits = remember(editing) { mutableStateMapOf<String, String>() }
    var insecure by remember(editing, profile) { mutableStateOf(profile.insecure == true) }
    val context = LocalContext.current

    LaunchedEffect(justSaved) {
        if (justSaved) {
            delay(1600)
            justSaved = false
        }
    }
    BackHandler { if (editing) editing = false else onBack() }

    val fields = remember(profile, editing) {
        DETAIL_FIELDS.filter { field ->
            profile.configType in field.types &&
                    (!field.read(profile).isNullOrBlank() || (editing && field.editAlways))
        }
    }
    val showInsecure = profile.configType in TLS_TYPES &&
            (editing || profile.insecure == true)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            // Swallow taps so nothing underneath (like the bottom bar) reacts through this page.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            DetailTopBar(
                palette = palette,
                editing = editing,
                justSaved = justSaved,
                onBack = { if (editing) editing = false else onBack() },
                onEditClick = {
                    if (editing) {
                        val updated = profile.copy()
                        edits[EDIT_KEY_NAME]?.let { updated.remarks = it.trim().ifEmpty { profile.remarks } }
                        fields.forEach { field ->
                            edits[field.label]?.let { field.write(updated, it) }
                        }
                        if (showInsecure) updated.insecure = insecure
                        onSave(updated)
                        editing = false
                        justSaved = true
                    } else {
                        editing = true
                    }
                }
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                DetailHero(
                    row = row,
                    palette = palette,
                    editing = editing,
                    nameValue = edits[EDIT_KEY_NAME] ?: profile.remarks,
                    onNameChange = { edits[EDIT_KEY_NAME] = it },
                    modifier = Modifier.iosEntrance(INTRO_ENTERING, 40)
                )
                val sections = listOf(
                    SECTION_CONNECTION to R.string.ios_sec_connection,
                    SECTION_TRANSPORT to R.string.ios_sec_transport,
                    SECTION_SECURITY to R.string.ios_sec_security,
                    SECTION_OTHER to R.string.ios_sec_other,
                )
                var order = 0
                sections.forEach { (section, titleRes) ->
                    val sectionFields = fields.filter { it.section == section }
                    val withInsecure = section == SECTION_SECURITY && showInsecure
                    if (sectionFields.isEmpty() && !withInsecure) return@forEach
                    order++
                    DetailSection(
                        title = stringResource(titleRes),
                        palette = palette,
                        modifier = Modifier.iosEntrance(INTRO_ENTERING, 40 + order * 90)
                    ) {
                        sectionFields.forEachIndexed { index, field ->
                            if (index > 0) DetailDivider(palette)
                            DetailFieldRow(
                                field = field,
                                palette = palette,
                                editing = editing,
                                value = edits[field.label] ?: field.read(profile).orEmpty(),
                                onChange = { edits[field.label] = it },
                                onCopy = { copyToClipboard(context, field.read(profile).orEmpty()) }
                            )
                        }
                        if (withInsecure) {
                            if (sectionFields.isNotEmpty()) DetailDivider(palette)
                            DetailSwitchRow(
                                label = stringResource(R.string.ios_allow_insecure),
                                checked = insecure,
                                enabled = editing,
                                palette = palette,
                                onCheckedChange = { insecure = it }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .iosEntrance(INTRO_ENTERING, 60 + (order + 1) * 90)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.accentSoft)
                        .clickable(role = Role.Button, onClick = onAdvancedEdit)
                        .padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_settings_24dp),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = palette.accent
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.ios_advanced_edit),
                        color = palette.accent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.navigationBarsPadding())
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun DetailTopBar(
    palette: IosPalette,
    editing: Boolean,
    justSaved: Boolean,
    onBack: () -> Unit,
    onEditClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(palette.card)
                .clickable(role = Role.Button, onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_arrow_back_24dp),
                contentDescription = stringResource(R.string.acc_back),
                modifier = Modifier.size(20.dp),
                tint = palette.accent
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = stringResource(R.string.ios_details_title),
            modifier = Modifier.weight(1f),
            color = palette.textPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        val label = when {
            editing -> stringResource(R.string.ios_save)
            justSaved -> stringResource(R.string.ios_saved)
            else -> stringResource(R.string.ios_edit)
        }
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(if (editing) palette.accentBrush else SolidColor(palette.accentSoft))
                .clickable(role = Role.Button, onClick = onEditClick)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = if (editing) Color.White else palette.accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DetailHero(
    row: ServerRowUiModel,
    palette: IosPalette,
    editing: Boolean,
    nameValue: String,
    onNameChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val profile = row.profile
    val delay = row.testDelayMillis
    val latency = when {
        delay > 0L -> stringResource(R.string.server_test_delay_value, delay)
        delay < 0L -> stringResource(R.string.ios_delay_failed)
        else -> stringResource(R.string.ios_not_tested)
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(palette.heroBrush)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            HeroChip(text = profile.configType.name)
            Spacer(Modifier.width(8.dp))
            HeroChip(text = "${stringResource(R.string.ios_latency)} $latency")
        }
        Spacer(Modifier.height(10.dp))
        if (editing) {
            OutlinedTextField(
                value = nameValue,
                onValueChange = onNameChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.ios_field_name)) },
                singleLine = true,
                textStyle = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White.copy(alpha = 0.8f),
                    cursorColor = Color.White,
                )
            )
        } else {
            Text(
                text = profile.remarks,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (row.typeDescription.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = row.typeDescription,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (!profile.server.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = profile.getServerAddressAndPort(),
                color = Color.White.copy(alpha = 0.85f),
                style = TextStyle(textDirection = TextDirection.Ltr, fontSize = 12.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun HeroChip(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.22f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun DetailSection(
    title: String,
    palette: IosPalette,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            color = palette.textSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 10.dp, top = 16.dp, bottom = 6.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(palette.card)
        ) {
            content()
        }
    }
}

@Composable
private fun DetailDivider(palette: IosPalette) {
    Box(
        Modifier
            .padding(start = 14.dp)
            .fillMaxWidth()
            .height(0.5.dp)
            .background(palette.separator)
    )
}

@Composable
private fun DetailFieldRow(
    field: DetailField,
    palette: IosPalette,
    editing: Boolean,
    value: String,
    onChange: (String) -> Unit,
    onCopy: () -> Unit,
) {
    if (editing) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            label = { Text(field.label) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = if (field.numeric) KeyboardType.Number else KeyboardType.Ascii
            ),
            textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 13.sp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = palette.textPrimary,
                unfocusedTextColor = palette.textPrimary,
                focusedBorderColor = palette.accent,
                unfocusedBorderColor = palette.separator,
                focusedLabelColor = palette.accent,
                unfocusedLabelColor = palette.textSecondary,
                cursorColor = palette.accent,
            )
        )
    } else {
        val shown = if (field.secret) "••••••••" else value
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(role = Role.Button, onClick = onCopy)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = field.label,
                color = palette.textSecondary,
                fontSize = 11.sp,
                maxLines = 1
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = shown,
                color = palette.textPrimary,
                style = TextStyle(textDirection = TextDirection.Ltr, fontSize = 13.sp, fontWeight = FontWeight.Medium),
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DetailSwitchRow(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    palette: IosPalette,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = palette.textPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedTrackColor = palette.accent,
                checkedThumbColor = Color.White,
            )
        )
    }
}

private fun copyToClipboard(context: Context, value: String) {
    if (value.isEmpty()) return
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    manager.setPrimaryClip(ClipData.newPlainText("", value))
    Toast.makeText(context, R.string.ios_copied, Toast.LENGTH_SHORT).show()
}
